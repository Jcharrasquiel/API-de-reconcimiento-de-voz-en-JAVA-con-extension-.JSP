/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//hacer "racha" de buenas seguidas, eliminacion automatica del texto al acertar, cambio de imagen automatica al acertar, mayor racha de aciertos, alertas emergentes, al ganar eliminacion de datos 



var imagenes = ["img/gato.jpg", "img/niño.jpg", "img/arbol.jpg", "img/casa.jpg", "img/celular.jpg", "img/sol.jpg", "img/perro.jpg",
    "img/globos.jpg", "img/libros.jpg", "img/helado.jpg"];


var RutImage = "";
var aciertos = 0;
var desaciertos = 0;
var seguidas = 0;
var racha = 0, intentos = 0;
var aux;
    


function verificar() {

    var palabra = document.getElementById("palabra").value.toLowerCase();
    var result = RutImage.indexOf(palabra);


    if(palabra.length === 0) {
    swal("Ops!", 'No has escrito nada en el campo', "error");
    return;
  }
  
    if (result !== -1) {

        aciertos++;
        document.getElementById("palabra").value = "";
        
        
        if (aciertos === 10) {
            swal("FELICITACIONES", "Has ganado", "success");
            aciertos = 0, desaciertos = 0, seguidas = 0, racha = 0, intentos = 0;
            document.getElementById("aciertos").value = "";
            document.getElementById("imagenSalida").src = "";
            document.getElementById("seguidas").value = "";
            document.getElementById("racha").value = "";
            document.getElementById("desaciertos").value = "";
        } else {
            seguidas++;
            document.getElementById("aciertos").value = aciertos;
            var numeroAlea = Math.floor(Math.random() * 10);
            RutImage = imagenes[numeroAlea];
            document.getElementById("imagenSalida").src = RutImage;
            document.getElementById("seguidas").value = seguidas;

            if (seguidas === 5) {
                swal("FELICITACIONES", "Has logrado varios aciertos", "success");
            }
        }
    } else {
        if (seguidas > racha) {
            racha = seguidas;
            document.getElementById("racha").value = racha;
        }
        desaciertos++;
        seguidas = 0;
        document.getElementById("desaciertos").value = desaciertos;
    }


}

function Obtener() {
    
    var numeroAlea = Math.floor(Math.random() * 10);
    if(aux===numeroAlea){
        if(numeroAlea>=9){
            numeroAlea--;
        }
        else if(numeroAlea<9){
            numeroAlea++;
        }
    }
    aux=numeroAlea;
    RutImage = imagenes[numeroAlea];
    document.getElementById("imagenSalida").src = RutImage;
}











