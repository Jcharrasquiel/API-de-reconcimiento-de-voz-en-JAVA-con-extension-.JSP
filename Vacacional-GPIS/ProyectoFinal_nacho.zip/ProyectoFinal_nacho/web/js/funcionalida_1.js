/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//hacer "racha" de buenas seguidas, eliminacion automatica del texto al acertar, cambio de imagen automatica al acertar, mayor racha de aciertos, alertas emergentes, al ganar eliminacion de datos 




var img = ["img/silabas/fa.JPG", "img/silabas/fe.JPG", "img/silabas/fi.JPG","img/silabas/fo.JPG", "img/silabas/fu.JPG", "img/silabas/ma.JPG", "img/silabas/me.JPG", "img/silabas/mi.JPG", "img/silabas/mo.JPG", "img/silabas/mu.JPG"];
var img_palabra = ["img/palabras/pera.jpg", "img/palabras/perro.jpg", "img/palabras/pila.jpg", "img/palabras/Pollito.jpg", "img/palabras/pirata.jpg" ];
var img_oraciones = ["img/oraciones/juan vio un árbol.jpg", "img/oraciones/Juan esta con su papá.jpg", "img/oraciones/aldair come una pera.jpg", "img/oraciones/Pedro pasea con su perro.jpg", "img/oraciones/Carlos alimenta a los pájaros.jpg"];
var aux = ["juan vio un árbol.", "juan está con su papá.", "Aldair come una pera.", "Pedro pasea con su perro.", "Carlos alimenta a los pájaros."];

var RutImage = "";
var i=0;
var j=0;
let rec;
    if (!("webkitSpeechRecognition" in window)) {
    	alert("disculpas, no puedes usar la API");
    } else {
    	rec = new webkitSpeechRecognition();
    	rec.lang = "es-COL";
    	rec.continuous = true;
    	rec.interim = true;
    	rec.addEventListener("result",iniciar);
    }
var texto = "";
function iniciar(event){
    
	for (let i = event.resultIndex; i < event.results.length; i++){
         document.getElementById("texto").value = event.results[i][0].transcript;
         document.getElementById("texto_palabra").value = event.results[i][0].transcript;
         document.getElementById("texto_oracion").value = event.results[i][0].transcript;
         texto = event.results[i][0].transcript;
	}
}

function hablar(){
    rec.start();
    
}
function veri(){
 
      var palabra = document.getElementById("texto").value.toLowerCase();
      var result = RutImage.indexOf(palabra);
      if (result !== -1) {
          swal("FELICITACIONES", "Has pronunciado bien", "success");
      }else{
          swal("LO SIENTO", "Has fallado", "error");
      }
      
     
        
    
}


function veri_palabra(){
 
      var palabra = document.getElementById("texto_palabra").value.toLowerCase();
      var result = RutImage.indexOf(palabra);
      if (result !== -1) {
          swal("FELICITACIONES", "Has pronunciado bien", "success");
      }else{
          
          swal("LO SIENTO", "Has fallado", "error");
      }
      
     
        
    
}



function veri_oracion(){
 
      var palabra = document.getElementById("texto_oracion").value.toLowerCase();
      j = i-1;
      var result = aux[j];
      if (result === palabra) {
          swal("FELICITACIONES", "Has pronunciado bien", "success");
      }else{
          alert(result);
          alert(palabra);
          swal("LO SIENTO", "Has fallado", "error");
      }
      
     
        
    
}


function imgs() {
    
    var numeroAlea = Math.floor(Math.random() * 10);
    if(aux===numeroAlea){
        if(numeroAlea>=9){
            numeroAlea--;
        }
        else if(numeroAlea<9){
            numeroAlea++;
        }
    }
    aux=numeroAlea;
    RutImage = img[numeroAlea];
    document.getElementById("imgSilaba").src = RutImage;
}

function imgs_palabra() {
    
    var numeroAlea = Math.floor(Math.random() * 5);
    if(aux===numeroAlea){
        if(numeroAlea>=9){
            numeroAlea--;
        }
        else if(numeroAlea<9){
            numeroAlea++;
        }
    }
    aux=numeroAlea;
    RutImage = img_palabra[numeroAlea];
    document.getElementById("imgPalabra").src = RutImage;
}

function imgs_oraciones() {
    
    
    RutImage = img_oraciones[i];
    document.getElementById("imgOracion").src = RutImage;
    i++;
    if (i>4){
        
        i=0;
        
    }
    
}













