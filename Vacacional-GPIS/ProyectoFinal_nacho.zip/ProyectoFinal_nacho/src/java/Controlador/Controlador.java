/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.LeccionES;
import Modelo.LeccionESDAO;
import Modelo.Usuario;
import Modelo.UsuarioDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author CARLOS DURAN
 */
public class Controlador extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    Usuario us = new Usuario();
    UsuarioDAO udao = new UsuarioDAO();
    LeccionES lec_es = new LeccionES();
    LeccionESDAO lec_esdao = new LeccionESDAO();
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion =request.getParameter("accion");
        switch(accion){
            case"agregarUsuario":
                    String identificacion=request.getParameter("identificacion");
                    String nombre=request.getParameter("nombre");
                    String apellido= request.getParameter("apellido");
                    String usuario= request.getParameter("username");
                    String contrasena= request.getParameter("contrasena");
                    String img= request.getParameter("img");
           
           String confirmarContrasena= request.getParameter("contrasenaa");
           
           
           if(contrasena.equalsIgnoreCase(confirmarContrasena)){
               us.setIdentificaion(identificacion);
             us.setNombre(nombre);
            us.setApellido(apellido);
           us.setUsername(usuario);
           us.setContrasena(contrasena);
           us.setImg(img);
            if(udao.agregarUsuario(us)==1){
                request.setAttribute("estado", "Usuario o identificacion ya existe");
               request.getRequestDispatcher("index.jsp").forward(request, response);
            }else{
                udao.agregarUsuario(us);
                request.setAttribute("estado", "Registro exitoso, ahora inicie sesion");
                request.getRequestDispatcher("index.jsp").forward(request, response);
            }
           
           }else{
               request.setAttribute("estado", "La contrasena no es igual");
               request.getRequestDispatcher("index.jsp").forward(request, response);
           }
            break;
            
            case "principal":
                
                
                request.setAttribute("username", us);
                request.getRequestDispatcher("principal.jsp").forward(request, response);
                
                break;
            case "enviar":
               
                    
                     
                    String id_usuario = request.getParameter("id_usuario");
                    String aciertos = request.getParameter("aciertos");
                    String desaciertos = request.getParameter("desaciertos");
                   int intentos = 10;
                    System.out.println(id_usuario + " " + aciertos + " " +  desaciertos);
                   int id_usuarioInt = Integer.parseInt(id_usuario);   
                    int aciertosInt = Integer.parseInt(aciertos);   
                    int desaciertosInt = Integer.parseInt(desaciertos); 
                 
                    lec_es.setId_usuario(id_usuarioInt);
                    lec_es.setAciertos(aciertosInt);
                    lec_es.setDesaciertos(desaciertosInt);
                    lec_es.setIntentos(intentos);
                    
                    lec_esdao.agregar(lec_es);
                    request.getRequestDispatcher("Controlador?accion=principal").forward(request, response);
                
                
                
                break;
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
