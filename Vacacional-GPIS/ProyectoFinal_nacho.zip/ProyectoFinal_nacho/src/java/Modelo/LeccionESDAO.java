/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author CARLOS DURAN
 */
public class LeccionESDAO {
 
     Conexion cn = new Conexion();
   Connection con;
   PreparedStatement ps;
   ResultSet rs;
   int r;
   
  public int agregar(LeccionES p){
     
    String sql = "insert into tleccionescribir(id_usuario, aciertos, desaciertos, intentos)values(?,?,?,?)";
       try{
           con = cn.Conexion();
           ps=con.prepareStatement(sql);
           ps.setInt(1, p.getId_usuario());
           ps.setInt(2, p.getAciertos());
           ps.setInt(3, p.getDesaciertos());
           ps.setInt(4, p.getIntentos());
           ps.executeUpdate();
       }catch(Exception e){
           System.out.println("Mesage Error" + e.getMessage());
       }
       return r;
       
   }
    
    
    
    
    
    
    
    
}
