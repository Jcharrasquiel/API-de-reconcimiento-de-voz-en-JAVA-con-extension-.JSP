/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author CARLOS DURAN
 */
public class LeccionES {
    int id;
    int id_usuario;
    int aciertos;
    int desaciertos;
    int intentos;

    public LeccionES() {
        
    }

    public LeccionES(int id, int id_usuario, int aciertos, int desaciertos, int intentos) {
        this.id = id;
        this.id_usuario = id_usuario;
        this.aciertos = aciertos;
        this.desaciertos = desaciertos;
        this.intentos = intentos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getAciertos() {
        return aciertos;
    }

    public void setAciertos(int aciertos) {
        this.aciertos = aciertos;
    }

    public int getDesaciertos() {
        return desaciertos;
    }

    public void setDesaciertos(int desaciertos) {
        this.desaciertos = desaciertos;
    }

    public int getIntentos() {
        return intentos;
    }

    public void setIntentos(int intentos) {
        this.intentos = intentos;
    }
    
    
    
    
}
